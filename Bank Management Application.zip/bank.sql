CREATE DATABASE BANK;

use BANK;

CREATE TABLE BRANCH(
Branch_name VARCHAR(40) NOT NULL,
Address_line1 VARCHAR(70),
Address_line2 VARCHAR(70),
City VARCHAR(40),
State VARCHAR(25),
Pincode INTEGER(6),
CONSTRAINT brname PRIMARY KEY (Branch_name)
);

insert into BRANCH values('Kankanady','Rainbox Complex','Downtown','Mangaluru','Karnataka','567777');
insert into BRANCH values('Talapady','Firoz Complex','Biri','Mangaluru','Karnataka','563555');
insert into BRANCH values('Kankanady','Rainbox Complex','Downtown','Mangaluru','Karnataka','567777');

CREATE TABLE CUSTOMER(
Cust_id BIGINT(15) NOT NULL AUTO_INCREMENT,
First_name VARCHAR(30),
Last_name VARCHAR(30),
DOB VARCHAR(10),
Address_line1 VARCHAR(70),
Address_line2 VARCHAR(70),
City VARCHAR(40),
State VARCHAR(25),
Pincode INTEGER(6),
Profession VARCHAR(15),
Branch_name VARCHAR(40),
Contact VARCHAR(10),
Email VARCHAR(40),
CONSTRAINT cid PRIMARY KEY (Cust_id),
CONSTRAINT br_name FOREIGN KEY(Branch_name) REFERENCES BRANCH(Branch_name) ON UPDATE CASCADE
);

insert into CUSTOMER values('100001','Prajnesh','Shetty','1998-04-11','Shivarama Krupa','Padil','Mangaluru','Karnataka','562211','Student','Kankanady','7688848888','prazss21@gmail.com');
insert into CUSTOMER values(default,'Nishant','John','1997-01-11','Blessing House','Puttur','Mangaluru','Karnataka','532211','Student','Kankanady','8711148888','nishant@gmail.com');
insert into CUSTOMER values(default,'Vikyath','Naiga','1997-01-09','Balya Balike','Biri','Mangaluru','Karnataka','534211','Student','Talapady','9832198828','vikkhi222@gmail.com');

CREATE TABLE ACCOUNT(
Acc_no BIGINT(15) NOT NULL,
Type VARCHAR(10),
Date_of_opening VARCHAR(10),
Balance FLOAT(15,2),
Status VARCHAR(10),
Status_date VARCHAR(10) DEFAULT NULL,
CONSTRAINT accno PRIMARY KEY (Acc_no),
CONSTRAINT acc_no FOREIGN KEY(Acc_no) REFERENCES CUSTOMER(Cust_id) ON UPDATE CASCADE
);

insert into ACCOUNT values('100001','Current','2016-09-09','10000','OPEN',NULL);
insert into ACCOUNT values('100002','Current','2016-09-09','10000','OPEN',NULL);
insert into ACCOUNT values('100003','Savings','2016-09-09','5000','OPEN',NULL);


CREATE TABLE LOGIN(
Cust_id BIGINT(15) NOT NULL,
Password VARCHAR(30),
Block VARCHAR(5),
CONSTRAINT c_id PRIMARY KEY (Cust_id),
CONSTRAINT acc_no_ FOREIGN KEY(Cust_id) REFERENCES CUSTOMER(Cust_id) ON UPDATE CASCADE
);

insert into LOGIN values('100001','prazss21','NO');
insert into LOGIN values('100002','nish123','NO');
insert into LOGIN values('100003','vik','NO');



CREATE TABLE ADMIN(
ID BIGINT(15) NOT NULL,
Password VARCHAR(30),
Branch_name VARCHAR(40),
CONSTRAINT id PRIMARY KEY (ID)
);

insert into ADMIN values('76543','7777','Kankanady');
insert into ADMIN values('1234','7777','Valachil');


CREATE TABLE DEPOSIT(
Dep_id BIGINT(15) NOT NULL AUTO_INCREMENT,
Acc_no BIGINT(15) NOT NULL,
Amount FLOAT(15,2),
Date VARCHAR(10),
CONSTRAINT did PRIMARY KEY (Dep_id)
);

CREATE TABLE WITHDRAWAL(
With_id BIGINT(15) NOT NULL AUTO_INCREMENT,
Acc_no BIGINT(15) NOT NULL,
Amount FLOAT(15,2),
Date VARCHAR(10),
CONSTRAINT wid PRIMARY KEY (With_id)
);

CREATE TABLE TRANSFER(
Trans_id BIGINT(15) NOT NULL AUTO_INCREMENT,
From_acc_no BIGINT(15) NOT NULL,
To_acc_no BIGINT(15) NOT NULL,
Amount FLOAT(15,2),
Date VARCHAR(10),
CONSTRAINT tid PRIMARY KEY (Trans_id)
);

delimiter //
create procedure addMoney(Custid BIGINT(15), Amount FLOAT(15,2))
BEGIN
update ACCOUNT set Balance=Balance+Amount where Acc_no=Custid;
END //
delimiter ;

call addMoney('100001','5000');

delimiter //
create procedure removeMoney(Custid BIGINT(15), Amount FLOAT(15,2))
BEGIN
update ACCOUNT set Balance=Balance-Amount where Acc_no=Custid;
END //
delimiter ;

call removeMoney('100002','1000');

delimiter //
create procedure transMoney(Custid BIGINT(15), Recid BIGINT(15), Amount FLOAT(15,2))
BEGIN
call removeMoney(Custid,Amount);
call addMoney(Recid,Amount);
END //
delimiter ;

call transMoney('100001','100002','300');
